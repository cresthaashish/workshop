## Learn Python3 the hard way. 

#### The main motivation to go through this book was to familiarize with basic python. The way author divided the content into exercise is amazing. 
